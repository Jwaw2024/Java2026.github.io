<?php
Broadcast::channel('App.User.{id}', function ($spbfa519, $spdc31ea) { return (int) $spbfa519->id === (int) $spdc31ea; });